'use client'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Container } from "@/components/ui/container";
import { Input } from "@/components/ui/input"
import { loginUser } from "@/lib/api/auth";
import { useSession } from "@/lib/contexts/session-context";
import { Lock, Mail, } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation";
import { useState } from "react"


export default function LoginPage() {
    const router = useRouter();
    const { checkSession } = useSession();
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");
        try {
            const response = await loginUser(email, password);

            // Store the token in localStorage
            localStorage.setItem("token", response.token);

            // Update session state
            await checkSession();

            // Wait for state to update before redirecting
            await new Promise((resolve) => setTimeout(resolve, 100));
            router.push("/dashboard");
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : "Invalid email or password. Please try again."
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-secondary/30">
            <Container className="flex flex-col items-center justify-center w-full">
                <Card className="w-full md:w-5/12 max-w-2xl p-8 md:p-10 rounded-3xl shadow-2xl border border-primary/10 bg-card/90 backdrop-blur-lg mt-12">
                    <div className="mb-6 text-center">
                        <h1 className="text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent mb-1 tracking-tight">
                            Welcome Back
                        </h1>
                        <p className="text-base text-muted-foreground font-medium">
                            Sign in to reconnect and continue your path toward mindful well-being.
                        </p>
                    </div>


                    {/* form component */}
                    <form className="space-y-6" onSubmit={handleSubmit}>
                        <div className="space-y-3">
                            {/* Email */}
                            <div>
                                <label
                                    htmlFor="email"
                                    className="block text-base font-semibold mb-1"
                                >
                                    Email
                                </label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                                    <Input id="email" type="email" placeholder="Enter your email" className="pl-12 py-2 text-base rounded-xl bg-card bg-opacity-80 border border-primary focus:outline-none focus:ring-2 focus:ring-primary text-white placeholder:text-muted-foreground" value={email} onChange={(e) => setEmail(e.target.value)} required />

                                </div>
                            </div>

                            {/* Password */}
                            <div>
                                <label
                                    htmlFor="password"
                                    className="block text-base font-semibold mb-1"
                                >
                                    Password
                                </label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                                    <Input id="password" type="password" placeholder="Enter your password" className="pl-12 py-2 text-base rounded-xl bg-card bg-opacity-80 border border-primary focus:outline-none focus:ring-2 focus:ring-primary text-black placeholder:text-muted-foreground" value={password} onChange={(e) => setPassword(e.target.value)} required />

                                </div>
                            </div>
                        </div>

                        {error && (
                            <p className="text-red-500 text-base text-center font-medium">
                                {error}
                            </p>
                        )}
                        <Button
                            className="w-full py-2 text-white rounded-xl font-bold bg-gradient-to-r from-primary to-primary/80 shadow-md hover:from-primary/80 hover:to-primary cursor-pointer"
                            size="lg"
                            type="submit"
                            disabled={loading}
                        >
                            {loading ? "Signing in..." : "Sign In"}
                        </Button>
                    </form>

                    {/* Extra navigation links */}
                    <div className="flex items-start justify-center gap-2 text-sm">
                        <span className="text-muted-foreground">
                            Don&lsquo;t have an account?
                        </span>
                        <Link href='/signup' className="text-primary font-semibold underline">
                            Sign Up
                        </Link>
                        <span className="text-muted-foreground">
                        </span>
                        <Link href={'/forgot-password'} className="text-primary underline">
                            Forgot Password?
                        </Link>

                    </div>
                </Card>
            </Container>

        </div>

    )
}