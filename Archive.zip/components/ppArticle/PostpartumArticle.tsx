/* eslint-disable react/no-unescaped-entities */
import Image from "next/image";
import React from "react";

const PostpartumArticle = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-10 text-foreground leading-relaxed bg-background">
      <h1 className="text-3xl font-bold mb-4 text-foreground">
        Understanding Postpartum Depression: Signs, Support, and Solutions
      </h1>

      <p className="text-lg mb-4 text-gray-700">
        Postpartum depression affects 1 in 5 mothers globally. Early detection,
        AI-powered screening, and professional support can improve outcomes for
        mothers and families.
      </p>

      <p className="mb-4">
        Postpartum depression (PPD) is a complex mental health condition that
        affects mothers after childbirth. It goes beyond the common "baby
        blues" and can include persistent sadness, overwhelming anxiety,
        irritability, and difficulty bonding with the newborn. PPD can occur
        within the first weeks to months after delivery and, if untreated, can
        last for a year or more.
      </p>

      <p className="mb-6">
        PPD impacts not only the mother but also the infant, partner, and entire
        family. Early recognition, professional intervention, and consistent
        support are crucial for recovery. MumWell provides a comprehensive
        platform to educate, screen, and guide mothers through this challenging
        period.
      </p>

      <div className="my-6 flex justify-center">
         <Image
          src="/ppd.jpg"
          height={600}
          width={600}
          alt="Healthy mother bonding with child"
          className="rounded-lg shadow-lg md:w-[60%] w-full md:h-72 h-52"
        />
      </div>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        Common Signs and Symptoms of Postpartum Depression
      </h3>

      <p className="mb-4">
        While every mother experiences the postpartum period differently, PPD
        has recognizable symptoms that can signal the need for support.
        Understanding these signs helps in early detection and timely
        intervention.
      </p>

      <ul className="list-disc pl-6 mb-6 space-y-2">
        <li>
          Persistent sadness, tearfulness, or hopelessness that lasts for more
          than two weeks
        </li>
        <li>Loss of interest or pleasure in daily activities and hobbies</li>
        <li>
          Intense anxiety, panic attacks, or obsessive thoughts about the baby
        </li>
        <li>Difficulty bonding with or caring for the newborn</li>
        <li>
          Changes in sleep or appetite unrelated to normal postpartum
          adjustments
        </li>
        <li>Feelings of guilt, inadequacy, or self-blame</li>
        <li>Fatigue and low energy that interferes with daily functioning</li>
        <li>
          Thoughts of self-harm or harming the baby (seek immediate help if
          present)
        </li>
      </ul>

      <p className="mb-6">
        If these symptoms are present, it's important to seek professional
        guidance as soon as possible. Early intervention improves outcomes for
        both mother and child.
      </p>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        Factors That Increase Risk of Postpartum Depression
      </h3>

      <p className="mb-4">
        While PPD can affect any mother, certain factors can increase
        vulnerability. Awareness of these risks allows families and healthcare
        providers to monitor and provide early support.
      </p>

      <div className="mb-6">
        <h4 className="font-semibold text-lg mb-2">Common Risk Factors:</h4>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <strong>Previous Mental Health Conditions:</strong> A history of
            depression, anxiety, or other mental health issues increases the
            likelihood of PPD.
          </li>
          <li>
            <strong>Stressful Life Events:</strong> Financial stress,
            relationship difficulties, or loss during pregnancy can contribute
            to depression.
          </li>
          <li>
            <strong>Lack of Social Support:</strong> Isolation from family,
            friends, or community networks can exacerbate postpartum stress.
          </li>
          <li>
            <strong>Complications During Pregnancy or Birth:</strong> Difficult
            deliveries, premature birth, or NICU stays for the baby can increase
            anxiety and depressive symptoms.
          </li>
          <li>
            <strong>Hormonal Changes:</strong> Rapid shifts in estrogen and
            progesterone after childbirth can affect mood regulation.
          </li>
        </ul>
      </div>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        The Importance of Early Detection
      </h3>

      <p className="mb-4">
        Timely recognition of PPD symptoms allows for early intervention,
        reducing the risk of long-term consequences for both mother and baby.
        Regular check-ins with healthcare providers, self-monitoring, and
        screening tools can help identify problems early.
      </p>

      <div className="mb-6">
        <h4 className="font-semibold text-lg mb-2">
          Early Detection Strategies:
        </h4>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <strong>Self-Assessment:</strong> Mothers can track mood, sleep
            patterns, and daily energy levels.
          </li>
          <li>
            <strong>Partner & Family Observations:</strong> Loved ones can
            notice changes in behavior, appetite, or bonding.
          </li>
          <li>
            <strong>AI-Powered Screening:</strong> Platforms like MumWell
            provide confidential digital assessments and guidance.
          </li>
          <li>
            <strong>Routine Medical Checkups:</strong> Healthcare providers
            should screen for PPD during postpartum visits.
          </li>
        </ul>
      </div>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        How MumWell Supports Mothers
      </h3>

      <p className="mb-4">
        MumWell combines technology, education, and professional care to support
        mothers experiencing postpartum depression. Our platform helps mothers
        and families navigate mental health challenges effectively.
      </p>

      <div className="mb-6">
        <h4 className="font-semibold text-lg mb-2">MumWell Key Features:</h4>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <strong>AI Screening:</strong> Scientific algorithms provide early
            risk assessments and identify warning signs quickly.
          </li>
          <li>
            <strong>AI Chat Guidance:</strong> Mothers receive immediate
            responses, coping strategies, and step-by-step guidance in a
            confidential environment.
          </li>
          <li>
            <strong>Professional Counseling:</strong> Licensed counselors
            provide personalized support through virtual or in-person sessions.
          </li>
          <li>
            <strong>Educational Resources:</strong> Comprehensive articles,
            videos, and tips empower mothers with knowledge about postpartum
            health.
          </li>
          <li>
            <strong>Community Support:</strong> Safe peer groups and forums
            allow mothers to share experiences and encouragement.
          </li>
        </ul>
      </div>

      <div className="bg-card border-l-4 border-slate-100 p-4 my-6 rounded">
        <p className="text-[#564356] font-medium">
          Proactive support reduces long-term risks, improves mother-child
          bonding, and strengthens family well-being.
        </p>
      </div>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        Coping Strategies for Mothers
      </h3>

      <p className="mb-4">
        In addition to professional support, mothers can use daily strategies to
        cope with stress and enhance mental well-being.
      </p>

      <ul className="list-disc pl-6 mb-6 space-y-2">
        <li>
          Practice self-care: short breaks, adequate sleep, and proper nutrition
        </li>
        <li>Accept help from family, friends, or support groups</li>
        <li>Engage in gentle physical activity or postpartum yoga</li>
        <li>Maintain social connections, even virtually</li>
        <li>Use journaling or mindfulness techniques to manage emotions</li>
        <li>Set realistic expectations and avoid self-blame</li>
      </ul>

      <h3 className="text-2xl font-semibold mt-8 mb-4">
        Why Maternal Mental Health Matters
      </h3>

      <p className="mb-4">
        Maternal mental health is critical for both the mother and the family.
        Untreated PPD can affect child development, family relationships, and
        maternal physical health. Educating families, removing stigma, and
        providing accessible resources ensures healthier outcomes for all.
      </p>

      <div className="my-6 flex justify-center">
        <Image
          src="/love.webp"
         height={600}
          width={600}
          alt="Healthy mother bonding with child"
          className="rounded-lg shadow-lg md:w-[60%] w-full md:h-72 h-52"
        />
      </div>

      <p className="mb-4">
        MumWell bridges the gap between mothers and timely care, providing
        tools, resources, and professional support that create meaningful
        improvements in maternal mental health.
      </p>
    </div>
  );
};

export default PostpartumArticle;
