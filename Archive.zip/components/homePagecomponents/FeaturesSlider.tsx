"use client"; 

import { ChevronLeft, ChevronRight } from 'lucide-react';

import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Image from 'next/image';


const mumWellFeatures = [
	{
		title: 'EPDS SCREENING',
		image: "/ai-screening.png",
		description:
			'Early detection of postpartum depression using validated EPDS questionnaire.',
		featured: true,
	},
	{
		title: 'AI CHATBOT',
		image: "/ai-chatbot.png",
		description:
			'24/7 empathetic support for mothers, answering questions and providing guidance.',
		featured: true,
	},
	{
		title: 'COUNSELING',
		image: "/counseling.png",
		description:
			'Connect with professional counselors for personalized tele-counseling sessions.',
		featured: true,
	},
	{
		title: 'RESOURCES',
		image: "/resources.png",
		description:
			'Access articles, videos, tips, and exercises to support maternal well-being.',
		featured: true,
	},
];

export function FeaturesSlider() {
	const PrevArrow = ({ onClick }: { onClick?: () => void }) => (
		<button
			onClick={onClick}
			className='absolute -left-4 top-1/2 -translate-y-1/2 z-10 p-2 text-[#1b3a68] bg-white rounded-full shadow hover:bg-[#1b3a68] hover:text-white transition'>
			<ChevronLeft size={28} />
		</button>
	);

	const NextArrow = ({ onClick }: { onClick?: () => void }) => (
		<button
			onClick={onClick}
			className='absolute -right-4 top-1/2 -translate-y-1/2 z-10 p-2 text-[#1b3a68] bg-white rounded-full shadow hover:bg-[#1b3a68] hover:text-white transition'>
			<ChevronRight size={28} />
		</button>
	);

	const settings = {
		dots: false,
		infinite: true,
		speed: 500,
		slidesToShow: 4,
		slidesToScroll: 1,
		arrows: true,
		prevArrow: <PrevArrow />,
		nextArrow: <NextArrow />,
		responsive: [
			{ breakpoint: 1024, settings: { slidesToShow: 3 } },
			{ breakpoint: 768, settings: { slidesToShow: 2 } },
			{ breakpoint: 480, settings: { slidesToShow: 1 } },
		],
	};

	return (
		<div className='bg-background py-8 sm:py-16 md:py-24 font-din-condensed max-w-screen'>
			<div className='max-w-5xl mx-auto px-8'>
				<div className='flex items-end mb-12'>
					<h2 className='text-2xl sm:text-3xl font-bold text-foreground md:mr-4 mr-2'>
						MUMWELL FEATURES
					</h2>
					
				</div>

				<div className='relative'>
					<Slider {...settings}>
						{mumWellFeatures.map((feature, i) => (
							<div key={i} className='px-2 group bg-card'>
								<div className='relative overflow-hidden h-64'>
									<div className='h-64'>
										<Image
											src={feature.image}
											alt={feature.title}
                                            fill
											className='w-full h-full object-cover'
										/>
									</div>
									<div
										className={`absolute inset-0 group-hover:flex items-center justify-center hidden group-hover:bg-[#202630] transition-all duration-300 pt-12`}>
										<div className='text-center text-white'>
											{feature.featured && (
												<>
													<h3 className='text-xl font-bold mb-2 whitespace-pre-line text-white'>
														{feature.title}
													</h3>
													<p className='text-sm mb-4 px-4'>
														{feature.description}
													</p>
													
												</>
											)}
										</div>
									</div>
								</div>
								<div className='text-center bg-card text-foreground p-4 pt-6 flex items-center justify-center group-hover:bg-[#202630] transition-all duration-300 group-hover:text-foreground'>
									<h3 className='text-xl font-bold mb-2 whitespace-pre-line group-hover:text-foreground'>
										{feature.title}
									</h3>
								</div>
							</div>
						))}
					</Slider>
				</div>
			</div>
		</div>
	);
};


