'use client';

import { LogOut, Menu, MessageCircle, X } from "lucide-react";
import Link from "next/link";
import ThemeToggle from "./theme-toggle";
import SignInButton from "./auth/sign-in-button";
import { useState } from "react";
import { Button } from "./ui/button";
import { useSession } from "@/lib/contexts/session-context";
import Image from "next/image";

export default function Header() {
  const navItems = [
    { href: "/about", label: "About MumWell" },
    { href: "/postpartum-depression", label: "Postpartum Depression" },
    { href: "/contact", label: "Contact" },
  ];
  const authNavItems = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/test", label: "Take Test" },
    { href: "/contact", label: "Emergency Contact" },
  ];

  const { isAuthenticated, logout } = useSession();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // console.log("Header: Auth state:", { isAuthenticated, user });

  return (
    <header className="fixed top-0 left-0 w-full z-[100] bg-[var(--nav-background)] mb-10">
      {/* Header background with subtle border and blur */}
      <div className="pointer-events-none absolute inset-0 bg-background/50 backdrop-blur-md border-b border-primary/10"></div>

      <div className="relative mx-auto max-w-6xl px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          {isAuthenticated ? (
            <Link
              href="/dashboard"
              className="flex items-center space-x-2 transition-opacity hover:opacity-80"
            >
              {/* <AudioWaveform className="h-7 w-7 text-primary animate-pulse-gentle" /> */}
              <div className="flex flex-col">
                <Image src="/mumwell.png" height={40} width={160} alt="MumWell Logo" />
              </div>
            </Link>

          ) : (
            <Link
              href="/"
              className="flex items-center space-x-2 transition-opacity hover:opacity-80"
            >
              {/* <AudioWaveform className="h-7 w-7 text-primary animate-pulse-gentle" /> */}
              <div className="flex flex-col">
                <Image src="/mumwell.png" height={40} width={160} alt="MumWell Logo" />
              </div>
            </Link>
          )}

          {/* Nav Items */}
          <div className="flex items-center gap-4 z-10">
            {isAuthenticated ? (
              <>
                <nav className="hidden md:flex items-center space-x-1">
                  {authNavItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
                    >
                      {item.label}
                      <span className="absolute bottom-0 left-0 w-full h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
                    </Link>
                  ))}
                </nav>
              </>
            ) : (
              <nav className="hidden md:flex items-center space-x-1">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
                  >
                    {item.label}
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
                  </Link>
                ))}
              </nav>
            )}


            {/* Right Actions */}
            <div className="flex items-center gap-1">
              <ThemeToggle />
              {isAuthenticated ? (
                <>
                  <Button
                    asChild
                    className=" gap-2 bg-[#6a5169] hover:bg-[#583a57]"
                  >
                    <Link href="/therapy/new">
                      <MessageCircle className="w-4 h-4 mr-1" />
                      Start Chat
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={logout}
                    className="hidden md:flex bg-red-500 hover:bg-red-700 text-muted-foreground hover:text-white cursor-pointer transition-colors"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign out
                  </Button>
                </>
              ) : (
                <SignInButton />
              )}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-primary/10 bg-background/90 backdrop-blur-lg mt-6 rounded-b-xl shadow-lg z-50 relative">
            <nav className="flex flex-col space-y-1 py-4 items-center">

              {isAuthenticated ? (
                <>
                  {authNavItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="px-4 py-3 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-primary/5 rounded-md transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ))}
                </>
              ) : (
                <>
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="px-4 py-3 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-primary/5 rounded-md transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ))}
                </>
              )}






              {isAuthenticated && (
                <Button
                  asChild
                  className="mt-2 mx-4 gap-2 bg-red-500 hover:bg-primary"
                  onClick={logout}
                >
                  {/* <Link href="/therapy/new"> */}
                  <LogOut className="w-4 h-4" />
                  <span>Sign out</span>
                  {/* </Link> */}
                </Button>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
