declare module "slick-carousel/slick/slick.css";
declare module "slick-carousel/slick/slick-theme.css";
